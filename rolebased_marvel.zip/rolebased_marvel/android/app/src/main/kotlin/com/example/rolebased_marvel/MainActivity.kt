package com.example.rolebased_marvel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
